import heart from "../assets/icons/heart.png";
import menu from "../assets/icons/1_logo.png";
import left from "../assets/icons/left.png";
import heartOutline from "../assets/icons/heart-ol.png";
import share from "../assets/icons/share.png";
import heartFilled from "../assets/icons/heart.png";
import settings from "../assets/icons/settings.png";
import clock from "../assets/icons/clock.png";
export default {
  heart,
  left,
  heartOutline,
  share,
  heartFilled,
  settings,
  clock,
  menu
};
