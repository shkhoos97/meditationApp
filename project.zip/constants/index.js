import icons from "./icons";
import { COLORS, FONT, SIZES, SHADOWS } from "./theme";

export {  icons, COLORS, FONT, SIZES, SHADOWS };
